function getScrollPercent() {
    var h = document.documentElement, 
        b = document.body,
        st = 'scrollTop',
        sh = 'scrollHeight';
    return (h[st]||b[st]) / ((h[sh]||b[sh]) - h.clientHeight) * 100;
}

function getheight(){
    var body = document.body,
    html = document.documentElement;

    var height = Math.max( body.scrollHeight, body.offsetHeight, 
                       html.clientHeight, html.scrollHeight, html.offsetHeight );
    return height;
}

function scroll(x){
    window.scrollBy({
        top: x,
        behavior : "smooth"
    })
}


/*
var sound = new Audio("https://dl.sndup.net/k3s2/click.mp3")
*/

/*if (document.location.host == "chapmanganato.to"){
    document.querySelector('[title="Read Manga Online - manganato"]').src = "https://i.ibb.co/ZS6KXYj/It-Consumes-colour.png";
    document.querySelector('[title="Read Manga Online - manganato"]').style.width = "200px"
    document.querySelector('[title="Read Manga Online - manganato"]').style.height = "100px"
}*/
currentchap = ""
if (document.location.host == "chapmanganato.to"){
    listofchapters = document.getElementsByClassName("navi-change-chapter")[0].options
    console.log(listofchapters)
    j = []
    for (var i = 0; i < listofchapters.length; i++) {
        j.push(listofchapters[i].dataset["c"]);
        //Do something
        if (listofchapters[i].includes("selected")){
            currentchap = listofchapters[i].dataset["c"]
        }
    }
}
console.log(j)



window.addEventListener(
    "keydown",
    (event) => {
if (event.defaultPrevented) {
        return; // Do nothing if the event was already processed
    }

if (document.location.host == "chapmanganato.to"||document.location.host == "chapmanganelo.com"){
    console.log("nato")
    classused = ["navi-change-chapter-btn-prev a-h","navi-change-chapter-btn-next a-h"]
    } else {
    classused = ["next","back"]
}

    

switch (event.key) {
    case "q":
        scroll(-700);
        break;
    case "e":
        scroll(700)
        break;

    case "w":
    scroll(-50);
    break;

    case "s":
    scroll(50);
    break;

    case "a":
    case "ArrowLeft":
        //sound.play()
        a = document.getElementsByClassName(classused[0]);
        if (a[1] == undefined){
            alert("this is the first chapter")
        }
        else if(getScrollPercent()< 30|| getScrollPercent() > 70||getheight()<10000){
            b = a[1].href
            window.location.href = b
        }
        break;

    case "d":   
    case "ArrowRight":
        //sound.play()
        a = document.getElementsByClassName(classused[1]);
        if (a[1] == undefined){
            alert("this is the last chapter :(")
        }
        else if(getScrollPercent()< 30|| getScrollPercent() > 70 ||getheight()<10000){
            b = a[1].href
            window.location.href = b
        }

        break;
    default:
        return; // Quit when this doesn't handle the key event.
    }

        // Cancel the default action to avoid it being handled twice
        event.preventDefault();
    },true,
);